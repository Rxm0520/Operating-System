package com.example.myprocessmanager;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;
//List adapter
public class ListAdapter extends BaseAdapter {
    // List context
    private final Context context;
    // List values
    private final List<RunningProcessInfo> values;

    public ListAdapter(Context context, List<RunningProcessInfo> values) {
        super();
        this.context = context;
        this.values = values;
    }

    @Override
    public int getCount() {
        return values.size();
    }

    @Override
    public Object getItem(int i) {
        return values.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //Initialize the components of each item
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.list_process_item, parent, false);
        ImageView imageView = (ImageView)rowView.findViewById(R.id.detailsIco);
        imageView.setImageDrawable(values.get(position).icon);
        TextView appName = (TextView) rowView.findViewById(R.id.appNameText);
        appName.setText(values.get(position).name);
        return rowView;
    }

}
