package com.example.myprocessmanager;

import android.graphics.drawable.Drawable;

public class RunningProcessInfo {
    private String mProcessInfoName;
    private String processInfo;
    private int mProcessInfoId;
    String packageName;
    String name;
    Drawable icon;
    boolean isUser;
    double memory;
    public RunningProcessInfo(String processInfoName,int pid){
        mProcessInfoName = processInfoName;
        this.mProcessInfoId = pid;
    }

    public String getProcessInfoName() {
        return mProcessInfoName;
    }

    public void setProcessInfoName(String processInfoName) {
        mProcessInfoName = processInfoName;
    }

    public String getProcessInfo() {
        return processInfo;
    }

    public void setProcessInfo(String processInfo) {
        this.processInfo = processInfo;
    }

    public int getProcessInfoId() {
        return mProcessInfoId;
    }

    public void setProcessInfoId(int processInfoId) {
        mProcessInfoId = processInfoId;
    }

    @Override
    public String toString() {
        return "RunningProcessInfo{" +
                "mProcessInfoName='" + mProcessInfoName + '\'' +
                '}';
    }
}
