package com.example.myprocessmanager;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.AppOpsManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int MY_PERMISSIONS_REQUEST_PACKAGE_USAGE_STATS = 1101;
    //List component
    ListView mListView;
    TextView mProcessesInfoTv;
    ListAdapter mListAdapter;
    Button updateBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.app_name);
        setContentView(R.layout.activity_main);
        mListView = findViewById(R.id.list_view);
        mProcessesInfoTv = findViewById(R.id.processesInfoTv);
        updateBtn = findViewById(R.id.updateBtn);
        // Obtain system data through system services
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        List<RunningProcessInfo> runningProcessInfoList = new ArrayList<>();

        // Obtain the remaining memory space according to the unit of kilobit
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        manager.getMemoryInfo(mi);
        double unUsedMemory = mi.availMem / 1024;

        //If the Android version is higher than 19, you need to apply for permission, and then obtain process information through USAGE_STATS_SERVICE
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (!hasPermission()) {
                startActivityForResult(
                        new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS),
                        MY_PERMISSIONS_REQUEST_PACKAGE_USAGE_STATS);
            }
            UsageStatsManager usm = (UsageStatsManager) this.getSystemService(Context.USAGE_STATS_SERVICE);
            long time = System.currentTimeMillis();
            List<UsageStats> appList = usm.queryUsageStats(UsageStatsManager.INTERVAL_BEST, time - 10 * 1000, time);
            if (appList != null && appList.size() > 0) {
                runningProcessInfoList = new ArrayList<>();
                for (UsageStats usageStats : appList) {
                    RunningProcessInfo runningProcessInfo = new RunningProcessInfo(usageStats.getPackageName(), -1);
                    runningProcessInfoList.add(runningProcessInfo);
                }
            }
        } else {
            //Versions below api19 get the process directly through the system service
            PackageManager pm = getApplicationContext().getPackageManager();
            List<ActivityManager.RunningAppProcessInfo> runningProcesses = manager.getRunningAppProcesses();
            for (RunningAppProcessInfo info : runningProcesses) {
                RunningProcessInfo processInfo = new RunningProcessInfo(info.processName, info.pid);
                processInfo.packageName = info.processName;// Package names

                try {
                    ApplicationInfo appInfo = pm.getApplicationInfo(
                            info.processName, 0);
                    processInfo.name = appInfo.loadLabel(pm).toString();
                    processInfo.icon = appInfo.loadIcon(pm);
                    int flags = appInfo.flags;

                    // Determine whether it is the system or the user
                    if ((flags & ApplicationInfo.FLAG_SYSTEM) == ApplicationInfo.FLAG_SYSTEM) {
                        processInfo.isUser = false;
                    } else {
                        processInfo.isUser = true;
                    }

                } catch (PackageManager.NameNotFoundException e) {

                    processInfo.name = info.processName;
                    processInfo.icon = getApplicationContext().getResources().getDrawable(
                            R.mipmap.ic_launcher);
                    processInfo.isUser = false;
                    e.printStackTrace();
                }

                int pid = info.pid;
                // Return memory information according to pid
                android.os.Debug.MemoryInfo[] memoryInfos = manager.getProcessMemoryInfo(new int[]{pid});
                long memory = memoryInfos[0].getTotalPrivateDirty()*1024;// Get the memory size occupied by the current process, the unit is kb

                processInfo.memory = memory;
                    runningProcessInfoList.add(processInfo);

            }
        }
        //listview，Data initialization of the list component and event monitoring processing for long-pressing the list
        if (runningProcessInfoList != null) {
            // Set data to the list adapter
            mListAdapter = new ListAdapter(this, runningProcessInfoList);
            mProcessesInfoTv.setText("Process num:" + runningProcessInfoList.size() + "  unUsedMemory:" + unUsedMemory + "KB");
            mListView.setAdapter(mListAdapter);
            mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                    final RunningProcessInfo runningProcessInfo = ((RunningProcessInfo) mListAdapter.getItem(i));
                    AlertDialog dialog = new AlertDialog.Builder(MainActivity.this).setMessage("Are you sure to kill this process?")
                            .setPositiveButton("confirm", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    clickToKillProcess(runningProcessInfo);
                                }
                            }).create();
                    dialog.show();
                    return true;
                }
            });

        } else {
            // In case there are no processes running (not a chance :))
            Toast.makeText(getApplicationContext(), "No application is running", Toast.LENGTH_LONG).show();
        }
        //Monitor of update button
        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    updateByStats();
                } else {
                    updateBefore5();
                }
            }
        });
    }

    public void clickToKillProcess(RunningProcessInfo runningProcessInfo) {
        String packageName = runningProcessInfo.getProcessInfoName();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

            try {
                int pid = runningProcessInfo.getProcessInfoId();
                if (packageName.equalsIgnoreCase("com.example.myprocessmanager")) {
                    android.os.Process.killProcess(android.os.Process.myPid());
                } else {
                    new AlertDialog.Builder(this).setTitle("Android 5.0 does not have permission to kill other processes").setMessage(runningProcessInfo.toString()).create().show();
                    updateByStats();
                }

            } catch (Exception e) {

                e.printStackTrace();

            }
        } else {
            int pid = runningProcessInfo.getProcessInfoId();
            if (android.os.Process.myPid() == pid) {
                android.os.Process.killProcess(pid);
            } else {
                ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
                manager.killBackgroundProcesses(packageName);
                updateBefore5();
            }
        }
    }

    /**
     * Before Android 5.0, all process information can be directly obtained by calling getRunningAppProcesses()
     */
    void updateBefore5() {
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> runningProcesses = manager.getRunningAppProcesses();
        List<RunningProcessInfo> runningProcessInfoList = new ArrayList<>();
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        manager.getMemoryInfo(mi);
        double unUsedMemory = mi.availMem / 1024;
        PackageManager pm = getApplicationContext().getPackageManager();
        for (RunningAppProcessInfo info : runningProcesses) {
            RunningProcessInfo processInfo = new RunningProcessInfo(info.processName, info.pid);
            processInfo.packageName = info.processName;// package name

            try {
                ApplicationInfo appInfo = pm.getApplicationInfo(
                        info.processName, 0);
                processInfo.name = appInfo.loadLabel(pm).toString();
                processInfo.icon = appInfo.loadIcon(pm);
                int flags = appInfo.flags;

                //  Determine whether it is the system or the user
                if ((flags & ApplicationInfo.FLAG_SYSTEM) == ApplicationInfo.FLAG_SYSTEM) {
                    processInfo.isUser = false;
                } else {
                    processInfo.isUser = true;
                }

            } catch (PackageManager.NameNotFoundException e) {

                processInfo.name = info.processName;
                processInfo.icon = getApplicationContext().getResources().getDrawable(
                        R.mipmap.ic_launcher);
                processInfo.isUser = false;
                e.printStackTrace();
            }

            int pid = info.pid;
            // Return memory information according to pid
            android.os.Debug.MemoryInfo[] memoryInfos = manager.getProcessMemoryInfo(new int[]{pid});
            long memory = memoryInfos[0].getTotalPrivateDirty()*1024;// Get the memory size occupied by the current process, the unit is kb

            processInfo.memory = memory;

                runningProcessInfoList.add(processInfo);
        }
        mListAdapter = new ListAdapter(this, runningProcessInfoList);
        mProcessesInfoTv.setText("Process num:" + runningProcessInfoList.size() + "  unUsedMemory:" + unUsedMemory + "KB");
        mListView.setAdapter(mListAdapter);
    }

    /**
     * Use the USAGE_STATS_SERVICE service to obtain the status of the process, here is used for Android5.0 and above
     */
    void updateByStats() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            UsageStatsManager usm = (UsageStatsManager) this.getSystemService(Context.USAGE_STATS_SERVICE);
            ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
            List<RunningProcessInfo> runningProcessInfoList = new ArrayList<>();
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            manager.getMemoryInfo(mi);
            double unUsedMemory = mi.availMem / 1024;
            long time = System.currentTimeMillis();
            List<UsageStats> appList = usm.queryUsageStats(UsageStatsManager.INTERVAL_BEST, time - 10 * 1000, time);
            if (appList != null && appList.size() > 0) {
                runningProcessInfoList = new ArrayList<>();
                for (UsageStats usageStats : appList) {
                    RunningProcessInfo runningProcessInfo1 = new RunningProcessInfo(usageStats.getPackageName(), -1);
                    runningProcessInfoList.add(runningProcessInfo1);
                }
            }
            mListAdapter = new ListAdapter(this, runningProcessInfoList);
            mProcessesInfoTv.setText("Process num:" + runningProcessInfoList.size() + "  unUsedMemory:" + unUsedMemory + "KB");
            mListView.setAdapter(mListAdapter);
        }
    }

    /**
     * Determine whether granted authority
     *
     * @return
     */
    private boolean hasPermission() {
        AppOpsManager appOps = (AppOpsManager)
                getSystemService(Context.APP_OPS_SERVICE);
        int mode = 0;
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
            mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(), getPackageName());
        }
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    /**
     *
     * Return after applying for permission
     *
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == MY_PERMISSIONS_REQUEST_PACKAGE_USAGE_STATS) {
            if (!hasPermission()) {
                //若用户未开启权限，则引导用户开启“Apps with usage access”权限
                startActivityForResult(
                        new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS),
                        MY_PERMISSIONS_REQUEST_PACKAGE_USAGE_STATS);
                updateByStats();
            }
        }
    }


}

